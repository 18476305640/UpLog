create definer = ``@`` trigger logIfDel
    before delete
    on log
    for each row
BEGIN
	delete from comment where log_id=old.log_id;
	DELETE FROM point_log WHERE log_id=old.log_id;
    END;

