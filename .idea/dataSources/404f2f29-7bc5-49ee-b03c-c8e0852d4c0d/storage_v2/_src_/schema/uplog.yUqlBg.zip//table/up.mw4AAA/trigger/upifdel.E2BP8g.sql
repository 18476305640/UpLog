create definer = ``@`` trigger upIfDel
    before delete
    on up
    for each row
BEGIN
	delete from log where up_id=old.up_id;
    END;

